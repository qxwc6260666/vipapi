<?php
$YUN_DATA=array (
  'url_jmp' => 
  array (
    0 => 
    array (
      'off' => '1',
      'name' => '小女花不弃',
      'url' => 'brq7blajvjhrcit',
      'title' => '小女花不弃',
      'part' => '1',
      'href' => 'https://baidu.com-l-baidu.com/20190108/10533_70028a0d/index.m3u8',
    ),
  ),
);
